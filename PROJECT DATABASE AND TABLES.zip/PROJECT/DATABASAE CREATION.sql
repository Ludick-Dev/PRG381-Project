CREATE DATABASE BCSTUDENTS
ON
(
NAME = 'bcstudents',
FILENAME ='C:\Program Files\Microsoft SQL Server\MSSQL15.MSSQLSERVER\MSSQL\DATA\bcStudents.mdf',
size = 5MB,
MAXSIZE = 100MB,
FILEGROWTH = 5%
)